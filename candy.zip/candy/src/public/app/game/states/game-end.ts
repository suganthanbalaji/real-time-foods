/// <reference path='../_references.ts' />

module GameApp.States {
	'use strict'; 
	
   export class GameEnd extends Phaser.State {
 
        create() {
 
        }
 
    }
}