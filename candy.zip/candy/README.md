This fork is created for an easy install demo showcasing candy crush game. Find more details on the use case at https://kandi.openweaver.com/collections/gaming/candy-crush
