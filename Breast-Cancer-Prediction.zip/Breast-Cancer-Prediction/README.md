# breast-cancer-prediction


Early stage diagnosis significantly increases the chances of survival. The key challenges against Breast cancer detection is how to classify tumors into malignant (cancerous) or benign(non cancerous).  We use a simple support vector machine implementation to determine key performance metrics.
